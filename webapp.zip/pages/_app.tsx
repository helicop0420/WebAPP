import "www/shared/styles/globals.css";
export { default } from "www/app";
