export { default } from "www/pages/deal";
