export { default } from "www/pages/profile";
