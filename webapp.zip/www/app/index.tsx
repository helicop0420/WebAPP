import MyApp from "./App";

export default MyApp;
