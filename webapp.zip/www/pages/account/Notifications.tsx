export function Notifications() {
  return (
    <div>
      <div className="bg-slate-50 px-2 py-3 rounded flex flex-col">
        <h3 className="text-xl mb-3">Email Notifications</h3>
      </div>
    </div>
  );
}
