export { default } from "./Deal";
