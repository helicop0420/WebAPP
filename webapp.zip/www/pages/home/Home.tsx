import { useGlobalState } from "www/shared/modules/global_context";
import UserHome from "./UserHome";
// import PublicHome from "./PublicHome";

export default function Home() {
  const { supabaseUser } = useGlobalState();
  if (supabaseUser) {
    return <UserHome isUserLoggedIn={true} />;
  }

  return <UserHome isUserLoggedIn={false} />;
  // return <PublicHome />;
}
