import Image from "next/image";
import React from "react";

export default function HomeHeader({ setShow }: { setShow: (show: boolean) => void }) {
  return (
    <div className="flex justify-between w-full px-[30px] py-[19px] bg-white items-center">
      <div className="flex items-center">
        <Image className="cursor-pointer" height={32} width={31} src="/logo.svg" alt="" />
        <p className="font-inter font-semibold text-2xl leading-[29px] text-green-700">ELMBASE</p>
      </div>
      <button
        className=" py-[21.5px] px-[31px] rounded-[6px] text-[#15803D] text-sm border border-green-700 bg-white h-[60px] w-[159px] leading-5 font-bold hover:bg-green-100 active:border-2"
        onClick={() => setShow(true)}
      >
        Sign In
      </button>
    </div>
  );
}
