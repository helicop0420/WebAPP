import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import { TypeAnimation } from "react-type-animation";
import { faEnvelope } from "@fortawesome/pro-thin-svg-icons";
import styles from "./Home.module.css";
import cx from "classnames";

export function HomeHeroHeader() {
  return (
    <div className="flex flex-col  items-center lg:items-start relative w-fit min-w-[500px]">
      <div className="font-inter font-normal sm:text-5xl text-4xl leading-[48px]  flex gap-2">
        <p className="  text-green-700"> Grow your </p>
        <TypeAnimation
          sequence={["net worth", 1000, "network"]}
          speed={15}
          deletionSpeed={15}
          wrapper="div"
          cursor={true}
          repeat={Infinity}
          className="text-gray-700 font-bold"
        />
      </div>
      <p className="lg:mt-6 mt-3 font-inter font-normal sm:text-xl text-lg  text-gray-500 max-w-[350px] lg:text-left text-center">
        A professional network for exclusive real estate opportunities
      </p>
    </div>
  );
}

export function HomeHeroFooter() {
  return (
    <div className="flex flex-col relative w-fit md:min-w-[515px] sm:px-0 px-3">
      <div className="lg:p-6 p-4 bg-white mt-6 rounded-[6px] shadow-[0px_10px_30px_rgba(0,0,0,0.1)]">
        <div className="w-full flex sm:gap-5 gap-2 items-center sm:flex-row flex-col">
          <div className="mt-1 flex rounded-md shadow-sm w-full flex-1">
            <span className="inline-flex rounded-l-[5px] border border-r-0 border-gray-200 bg-[rgba(209,219,227,0.2)] px-3 text-sm text-gray-500 sm:h-[60px] h-[42px] w-[59px] justify-center items-center">
              <FontAwesomeIcon icon={faEnvelope} className="h-6 w-6" />
            </span>
            <div className={cx("relative rounded-md  w-full", styles.hero)}>
              <input
                type="text"
                name="email"
                id="email"
                className={cx(
                  "block w-full rounded-r-md border-l-0 border-gray-300 px-4 py-[20px] focus:border-green-500 focus:ring-green-500 sm:text-sm sm:h-[60px] h-10 font-light text-sm leading-[17px] text-[#828B93] bg-white "
                )}
                placeholder="Your Email"
              />
            </div>
          </div>
          <button className="font-medium text-sm leading-[20px] text-white bg-green-700 sm:py-[20px] sm:px-[26px] rounded-md hover:bg-green-800 active:bg-green-700 active:box-border active:border-2 active:border-green-800 sm:h-[60px] h-10 sm:w-auto w-full">
            Join Waitlist
          </button>
        </div>
      </div>
      <p
        className="
          font-normal text-xs leading-[150%] text-gray-500 lg:mt-6 mt-4"
      >
        Currently the platform is referrals-only. Join the waitlist to be
        invited for early access.
      </p>
    </div>
  );
}
