import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEnvelope, faLock, faEyeSlash, faEye } from "@fortawesome/pro-thin-svg-icons";
import Image from "next/image";
import Link from "next/link";
import SlideOver from "www/shared/components/slideOver/SlideOver";
import styles from "./Home.module.css";
import cx from "classnames";
interface ProviderButtonProps {
  provider: string;
  onClick: () => void;
  iconPath: string;
}
interface AuthPageProps {
  show: boolean;
  setShow: (show: boolean) => void;
}
export default function Auth({ show, setShow }: AuthPageProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [showLoginForm, setShowLoginForm] = useState(false);
  return (
    <SlideOver show={show} setShow={setShow}>
      <div className="h-full min-h-screen flex items-center pt-[16.67%] flex-col bg-[#F5F7F9]  w-full ">
        <div className="max-w-[350px] w-full space-y-[30px] ">
          <p className="font-inter font-medium text-[32px] leading-[39px] text-green-700 mb-[30px] text-center">
            Sign In
          </p>
          <div className="flex flex-col space-y-6  w-full justify-center">
            <ProviderButton iconPath="/google.svg" provider="Continue with Google" onClick={() => {}} />
            <ProviderButton iconPath="/linkedin.svg" provider="Continue with Linkedin" onClick={() => {}} />
          </div>
          <p
            className="font-inter font-medium text-base leading-[39px] text-[#15803D] text-center cursor-pointer"
            onClick={() => {
              setShowLoginForm(!showLoginForm);
            }}
          >
            Sign In with Email address
          </p>
          {showLoginForm && (
            <div className="w-full">
              <form action="" className={cx("relative rounded-md shadow-sm w-full", styles.loginForm)}>
                <div className="w-full space-y-6">
                  {/* email */}
                  <div className="w-full">
                    <div className="mt-1 flex rounded-md shadow-sm w-full">
                      <span className="inline-flex rounded-l-[5px] border border-r-0 border-gray-200 bg-[rgba(209,219,227,0.2)] px-3 text-sm text-gray-500 h-[60px] w-[59px] justify-center items-center">
                        <FontAwesomeIcon icon={faEnvelope} className="h-6 w-6" />
                      </span>
                      <div className="relative rounded-md shadow-sm w-full">
                        <input
                          type="text"
                          name="email"
                          id="email"
                          className="block w-full rounded-r-md border-gray-300 px-4 py-[21.5px] focus:border-green-500 focus:ring-green-500 sm:text-sm h-[60px] font-light text-sm leading-[17px] text-[#828B93] bg-white "
                          placeholder="Your Email"
                        />
                      </div>
                    </div>
                  </div>
                  {/* Password */}
                  <div className="w-full">
                    <div className="mt-1 flex rounded-md shadow-sm w-full">
                      <span className="inline-flex rounded-l-[5px] border border-r-0 border-gray-200 bg-[rgba(209,219,227,0.2)] px-3 text-sm text-gray-500 h-[60px] w-[59px] justify-center items-center">
                        <FontAwesomeIcon icon={faLock} className="h-6 w-6" />
                      </span>
                      <div className="relative rounded-md shadow-sm w-full">
                        <input
                          type={showPassword ? "text" : "password"}
                          name="password"
                          id="password"
                          className="block w-full rounded-r-md border-gray-300 pl-4 pr-10 py-[21.5px] focus:border-green-500 focus:ring-green-500 sm:text-sm h-[60px] font-light text-sm leading-[17px] text-[#828B93] bg-white  autofill:bg-white "
                          placeholder="Your Password"
                        />
                        <div className="cursor-pointer absolute inset-y-0 right-0 flex items-center pr-3">
                          <FontAwesomeIcon
                            icon={showPassword ? faEyeSlash : faEye}
                            className="h-6 w-5 text-green-700 font-light text-[19.2px] leading-[19px]"
                            aria-hidden="true"
                            onClick={() => setShowPassword(!showPassword)}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                  <Link href="#">
                    <a className="text-green-700 text-right w-full block">Forgot Password?</a>
                  </Link>
                  {/* <p className="text-green-700 text-right">Forgot password?</p> */}
                </div>
                <button
                  className="bg-[#15803D] font-inter font-normal text-sm leading-[150%] text-white py-[19.5px] flex gap-2 items-center justify-center border border-[#D1DBE3]  rounded-[6px] shadow-[0px_10px_20px_rgba(0,0,0,0.2)] w-full max-w-[350px] mx-auto mt-6"
                  onClick={() => {}}
                >
                  Sign In
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </SlideOver>
  );
}

const ProviderButton = ({ provider, onClick, iconPath }: ProviderButtonProps) => {
  return (
    <button
      className="bg-white font-inter font-normal text-sm leading-[150%] text-[#353636] py-[19.5px] flex gap-2 items-center justify-center border border-[#D1DBE3]  rounded-[6px] w-full max-w-[350px] mx-auto "
      onClick={onClick}
    >
      <Image src={iconPath} alt="linkedin" height="24" width="24" />
      {provider}
    </button>
  );
};
