import { faFolderOpen, faThumbsUp } from "@fortawesome/free-regular-svg-icons";
import {
  faChevronDown,
  faChevronUp,
  faFilter,
  faPaperclip,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { ConversationPreview, DealInterestLevel, Deals } from "types/views";
import { useRouter } from "next/router";
import { Popover } from "@headlessui/react";
import { ReactNode, useMemo, useState } from "react";
import { CheckboxWithLabel } from "www/shared/components/form_inputs/Checkbox";
import { useGlobalState } from "www/shared/modules/global_context";
import { getUrlQueryString } from "www/shared/utils";
import Image from "next/image";
import { useQuery } from "react-query";
import {
  AttachmentPopoverQuerykey,
  getAllFilenamesForDeals,
} from "./AttachmentPopover.fetchers";

function getParamValue(
  param: string | string[] | undefined,
  defaultValue = true
) {
  if (!param) {
    return defaultValue;
  }

  return param === "true";
}

export function useInboxFilterQueryParams() {
  const router = useRouter();
  const routerQuery = router.query as {
    [key: string]: string;
  };

  const deals = useGlobalState((s) => s.sponsorDeals);

  return useMemo(() => {
    const slightlyInterested = getParamValue(
      routerQuery[DealInterestLevel.SlightlyInterested]
    );
    const moderatelyInterested = getParamValue(
      routerQuery[DealInterestLevel.ModeratelyInterested]
    );
    const veryInterested = getParamValue(
      routerQuery[DealInterestLevel.VeryInterested]
    );

    const interestLevels: DealInterestLevel[] = [];
    if (slightlyInterested) {
      interestLevels.push(DealInterestLevel.SlightlyInterested);
    }

    if (moderatelyInterested) {
      interestLevels.push(DealInterestLevel.ModeratelyInterested);
    }
    if (veryInterested) {
      interestLevels.push(DealInterestLevel.VeryInterested);
    }

    const onToggleInterestLevel = (interestLevel: DealInterestLevel) => {
      const hasInterestLevel = interestLevels.includes(interestLevel);

      if (hasInterestLevel && interestLevels.length === 1) {
        alert("Need at least one interest level selected");
        return;
      }

      router.replace({
        query: {
          ...routerQuery,
          [interestLevel]: !hasInterestLevel,
        },
      });
    };

    const onToggleField =
      (field: string, defaultValue = true) =>
      () => {
        router.replace({
          query: {
            ...routerQuery,
            [field]: !getParamValue(routerQuery[field], defaultValue),
          },
        });
      };

    const attachmentIds = routerQuery["attachmentIds"]
      ? routerQuery["attachmentIds"].split(",").map(Number)
      : [];

    const onToggleAttachmentIds = (attachId: number) => {
      let newAttachments = [...attachmentIds];
      const hasAttachIdAlready = attachmentIds.includes(attachId);

      if (hasAttachIdAlready) {
        newAttachments = newAttachments.filter((id) => id !== attachId);
      } else {
        newAttachments.push(attachId);
      }

      const newQuery = {
        ...routerQuery,
        attachmentIds: newAttachments.join(","),
      };
      if (newAttachments.length === 0) {
        // @ts-ignore
        delete newQuery.attachmentIds;
      }

      router.replace({
        query: newQuery,
      });
    };

    const indicatedInterest = getParamValue(
      routerQuery["indicatedInterest"],
      false
    );
    const onToggleIndicatedInterest = onToggleField("indicatedInterest");

    const showArchivedConversations = getParamValue(
      routerQuery["showArchivedConversations"],
      false
    );
    const onToggleShowArchivedConversations = onToggleField(
      "showArchivedConversations",
      false
    );

    const dealIds = routerQuery["dealIds"]
      ? routerQuery["dealIds"].split(",").map(Number)
      : [];

    const onToggleDealIds = (dealId: number) => {
      let newDeals = [...dealIds];
      const hasDealIdAlready = dealIds.includes(dealId);

      if (hasDealIdAlready) {
        if (newDeals.length === 1) {
          alert("Need at least one deal selected");
          return;
        }

        newDeals = newDeals.filter((id) => id !== dealId);
      } else {
        newDeals.push(dealId);
      }

      router.replace({
        query: {
          ...routerQuery,
          dealIds: newDeals.join(","),
        },
      });
    };
    if (deals && deals.length > 0 && dealIds.length === 0) {
      const firstActiveDeal = deals
        .filter((deal) => deal.is_active)
        .sort(
          (a, b) =>
            new Date(a.created_at).getDate() - new Date(b.created_at).getDate()
        )[0];

      if (firstActiveDeal) {
        dealIds.push(firstActiveDeal.id);
      }
    }

    return {
      interestLevels,
      onToggleInterestLevel,
      indicatedInterest,
      onToggleIndicatedInterest,
      attachmentIds,
      onToggleAttachmentIds,
      showArchivedConversations,
      onToggleShowArchivedConversations,
      dealIds,
      onToggleDealIds,
      deals,
    };
  }, [deals, getUrlQueryString()]);
}

function useFilenamesForDeals() {
  const dealIds = useGlobalState((s) => s.sponsorDeals).map((deal) => deal.id);

  const { data: fileNameRes } = useQuery({
    queryKey: [AttachmentPopoverQuerykey.Filenames, dealIds.join(",")],
    queryFn: () => getAllFilenamesForDeals(dealIds),
  });

  return fileNameRes?.data || [];
}

export function InboxPopover({
  chatList,
}: {
  chatList: ConversationPreview[];
}) {
  console.log({ chatList });
  const filenames = useFilenamesForDeals();
  const {
    interestLevels,
    onToggleInterestLevel,
    indicatedInterest,
    onToggleIndicatedInterest,
    attachmentIds,
    onToggleAttachmentIds,
    showArchivedConversations,
    onToggleShowArchivedConversations,
    deals,
    dealIds,
    onToggleDealIds,
  } = useInboxFilterQueryParams();

  const { activeDeals, inactiveDeals } = useMemo(() => {
    let activeDeals: Deals[] = [];
    let inactiveDeals: Deals[] = [];

    deals.forEach((deal) => {
      if (deal.is_active) {
        activeDeals.push(deal);
      } else {
        inactiveDeals.push(deal);
      }
    });

    return {
      activeDeals,
      inactiveDeals,
    };
  }, [deals]);

  return (
    <div className="flex justify-between  border-b border-gray-100 pb-2">
      <div className="text-xs leading-4 font-normal text-gray-500">
        Showing {chatList?.length} conversations.
      </div>

      <Popover className="relative">
        <Popover.Button>
          <FontAwesomeIcon icon={faFilter} className="text-sm" />
        </Popover.Button>
        <Popover.Panel className="absolute z-10 bg-white w-[320px] shadow-lg rounded-md overflow-y-auto max-h-[400px]">
          <InboxPopoverHeader title="Interest Level" />
          <div className="py-1 text-sm ">
            <InboxPopoverBodyItem>
              <CheckboxWithLabel
                id={DealInterestLevel.SlightlyInterested}
                checked={interestLevels.includes(
                  DealInterestLevel.SlightlyInterested
                )}
                icon={
                  <Image
                    src="/icons/slightlyInterested.svg"
                    alt="Low interest"
                    height={16}
                    width={16}
                  />
                }
                onChange={() => {
                  onToggleInterestLevel(DealInterestLevel.SlightlyInterested);
                }}
                label={"Slightly Interested"}
              />
            </InboxPopoverBodyItem>
            <InboxPopoverBodyItem>
              <CheckboxWithLabel
                id={DealInterestLevel.ModeratelyInterested}
                checked={interestLevels.includes(
                  DealInterestLevel.ModeratelyInterested
                )}
                icon={
                  <Image
                    src="/icons/moderatelyInterested.svg"
                    alt="Moderate interest"
                    height={16}
                    width={16}
                  />
                }
                onChange={() => {
                  onToggleInterestLevel(DealInterestLevel.ModeratelyInterested);
                }}
                label={"Moderately Interested"}
              />
            </InboxPopoverBodyItem>
            <InboxPopoverBodyItem>
              <CheckboxWithLabel
                id={DealInterestLevel.VeryInterested}
                checked={interestLevels.includes(
                  DealInterestLevel.VeryInterested
                )}
                icon={
                  <Image
                    src="/icons/veryInterested.svg"
                    alt="High interest"
                    height={16}
                    width={16}
                  />
                }
                onChange={() => {
                  onToggleInterestLevel(DealInterestLevel.VeryInterested);
                }}
                label={"Very Interested"}
              />
            </InboxPopoverBodyItem>
          </div>
          <InboxPopoverHeader title="Indicated interest" />
          <InboxPopoverBodyItem>
            <CheckboxWithLabel
              id="indicatedInterest"
              label="Indicated Interest"
              icon={
                <FontAwesomeIcon
                  icon={faThumbsUp}
                  className="mr-1"
                  fontSize={16}
                />
              }
              checked={indicatedInterest}
              onChange={onToggleIndicatedInterest}
            />
          </InboxPopoverBodyItem>
          <InboxPopoverHeader title="Attachments Received" />
          {filenames.map((attachmentInfo) => {
            return (
              <InboxPopoverBodyItem key={attachmentInfo.id}>
                <CheckboxWithLabel
                  id={String(attachmentInfo.id)}
                  label={attachmentInfo.filename}
                  icon={
                    <FontAwesomeIcon
                      icon={faPaperclip}
                      className="mr-1"
                      fontSize={16}
                    />
                  }
                  checked={attachmentIds.includes(attachmentInfo.id)}
                  onChange={() => onToggleAttachmentIds(attachmentInfo.id)}
                />
              </InboxPopoverBodyItem>
            );
          })}
          <InboxPopoverHeader title="Marked Done" />
          <InboxPopoverBodyItem>
            <CheckboxWithLabel
              id="ArchivedConversations"
              label="Show archived conversations"
              icon={<FontAwesomeIcon icon={faFolderOpen} className="mr-1" />}
              checked={showArchivedConversations}
              onChange={onToggleShowArchivedConversations}
            />
          </InboxPopoverBodyItem>
          <InboxPopoverHeader title="Deals" />
          {activeDeals.map((deal) => {
            return (
              <InboxPopoverBodyItem key={deal.id}>
                <CheckboxWithLabel
                  id={String(deal.id)}
                  label={deal.title!}
                  checked={dealIds.includes(deal.id)}
                  onChange={() => {
                    onToggleDealIds(deal.id);
                  }}
                />
              </InboxPopoverBodyItem>
            );
          })}
          {inactiveDeals.length > 0 && (
            <InboxPopoverCollapsibleSection header="Inactive">
              {inactiveDeals.map((deal) => {
                return (
                  <InboxPopoverBodyItem key={deal.id}>
                    <CheckboxWithLabel
                      id={String(deal.id)}
                      label={deal.title!}
                      checked={dealIds.includes(deal.id)}
                      onChange={() => {
                        onToggleDealIds(deal.id);
                      }}
                    />
                  </InboxPopoverBodyItem>
                );
              })}
            </InboxPopoverCollapsibleSection>
          )}
        </Popover.Panel>
      </Popover>
    </div>
  );
}

export function InboxPopoverHeader({ title }: { title: string }) {
  return (
    <div className="bg-gray-100 text-black text-sm leading-5 font-medium p-2">
      {title}
    </div>
  );
}

export function InboxPopoverBodyItem({ children }: { children: ReactNode }) {
  return (
    <div className="py-2 px-4 text-sm leading-5 font-normal">{children}</div>
  );
}

export function InboxPopoverCollapsibleSection({
  header,
  children,
}: {
  header: string;
  children: ReactNode;
}) {
  const [collapsed, setCollapsed] = useState(false);
  return (
    <>
      <div
        className="border-y border-y-gray-200 text-black text-sm leading-5 font-medium py-2 px-4 flex justify-between cursor-pointer "
        onClick={() => {
          setCollapsed(!collapsed);
        }}
      >
        <div>{header}</div>
        <FontAwesomeIcon
          icon={collapsed ? faChevronDown : faChevronUp}
          fontSize={16}
        />
      </div>
      {!collapsed ? children : null}
    </>
  );
}
