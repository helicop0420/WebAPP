import Link from "next/link";
import { useState } from "react";
import PageCenteredCard from "www/shared/components/layout/PageCenteredCard";
import { LoadingItem, useGlobalState } from "www/shared/modules/global_context";
import { clientSupabase } from "www/shared/modules/supabase";

interface LoginForm {
  username: { value: string };
  password: { value: string };
}

export default function Login() {
  const [error, setError] = useState<string | null>(null);
  const loading = useGlobalState((s) => s.loading);
  const promiseLoadingHelper = useGlobalState((s) => s.promiseLoadingHelper);
  const loginLoadingItem: LoadingItem = { componentName: "login" };
  const loginEmailPassword = async (form: LoginForm) => {
    setError(null);
    const res = await clientSupabase.auth.signIn({
      email: form.username.value,
      password: form.password.value,
    });
    if (res.error !== null) {
      let errorMessage = res.error.message;
      if (errorMessage === "Email not confirmed") {
        errorMessage = "Account pending approval";
      }
      setError(errorMessage);
      return;
    }
  };

  return (
    <PageCenteredCard>
      <div className="px-6 py-4">
        <div className="font-bold text-xl mb-2">Sign in</div>
        <div>Stay updated on your real estate deals</div>
      </div>
      <form
        className="px-6 pt-2 pb-8 mb-4"
        onSubmit={(evt) => {
          evt.preventDefault();
          loginEmailPassword(evt.target as any as LoginForm).finally(
            promiseLoadingHelper(loginLoadingItem)
          );
        }}
      >
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2">
            Email Address
          </label>
          <input
            className="bg-slate-200 shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            name="username"
            type="email"
            placeholder="example@mail.com"
            required
            disabled={loading}
          />
        </div>
        <div className="mb-3">
          <label className="block text-gray-700 text-sm font-bold mb-2">
            Password
          </label>
          <input
            className="bg-slate-200 shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline"
            name="password"
            type="password"
            placeholder="******************"
            required
            disabled={loading}
          />
        </div>
        {error !== null && (
          <div className="flex px-6 py-2 rounded bg-red-100 text-red-800">
            {error}
          </div>
        )}
        <div className="flex items-center justify-between mb-6 mt-3">
          <div className="flex items-center text-sm align-baseline">
            New to Elmbase?&nbsp;
            <Link href="/signup">
              <span className="font-bold  text-green-600 hover:text-green-700 cursor-pointer">
                Sign Up
              </span>
            </Link>
          </div>
          <button
            className="bg-green-600 hover:bg-green-700 text-white font-semibold py-1 px-4 rounded focus:outline-none focus:shadow-outline"
            type="submit"
            disabled={loading}
          >
            {loading && "Working..."}
            {!loading && "Sign In"}
          </button>
        </div>
        <div className="flex justify-center">
          <Link href="/recover">
            <span className="inline-block align-baseline font-bold text-sm text-green-600 hover:text-green-700 cursor-pointer">
              Forgot Password?
            </span>
          </Link>
        </div>
      </form>
    </PageCenteredCard>
  );
}
