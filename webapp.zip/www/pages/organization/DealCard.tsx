import Image from "next/image";
import Link from "next/link";
import React from "react";

export default function DealCard() {
  return (
    <div className="min-w-[334px] lg:max-w-[334px] bg-white shadow-lg rounded-lg">
      <div className="">
        <Image
          src="/organization/dealImg.png"
          width="334"
          height="168"
          className=" max-w-[334px] max-h-[168px] rounded-t-lg"
          alt=""
        />
      </div>
      <div className="p-4">
        <span className="">
          <p className="text-sm leading-5 font-medium text-green-700 flex space-x-1 items-center">
            <CheckIcon /> Active
          </p>
        </span>
        <Link href="" className="text-lg leading-7 font-semibold">
          <a className="text-lg leading-7 font-semibold text-gray-900">
            78-Acre Commercial & Residential Development in Elgin, TX
          </a>
        </Link>
        <p className="text-sm leading-5 font-normal mt-2 text-gray-500">
          An opportunity to invest in the acquisition and entitlement (“Phase
          1”) of approximately 76 acres of land located at 18401 US 290, Elgin,
          Texas, only 25 minutes from downtown Austin.
        </p>
        <p className="text-gray-500 mt-2 text-xs leading-4 font-normal">
          <span className="font-bold text-green-700">20 people</span> have
          expressed interest.
        </p>
      </div>
    </div>
  );
}

const CheckIcon = () => {
  return (
    <svg
      width="10"
      height="7"
      viewBox="0 0 10 7"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M1.5 4L3.5 6L8.5 1"
        stroke="#15803D"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
