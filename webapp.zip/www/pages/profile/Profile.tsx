import Header from "./Header";
import About from "./About";
import Projects from "./Projects";
import Endorsements from "./Endorsements";
import { useEffect, useState } from "react";
import { db } from "www/shared/modules/supabase";
import { useRouter } from "next/router";
import { LoadingItem, useGlobalState } from "www/shared/modules/global_context";
import { ProfilePageView } from "types/views";
import Modal from "www/shared/components/modal/Modal";
import EditProfileForm from "./EditProfileForm";
import { Organization } from "types/tables";
export default function Profile() {
  const [_error, setError] = useState<string | null>(null);
  const [_success, setSuccess] = useState<string | null>(null);
  const [profileData, setProfileData] = useState<ProfilePageView>();
  const [organizations, setOrganizations] = useState<Organization["Row"][]>();
  const router = useRouter();
  const promiseLoadingHelper = useGlobalState((s) => s.promiseLoadingHelper);
  const userProfileLoadingItem: LoadingItem = { componentName: "profile" };
  const [open, setOpen] = useState(false);

  const { handle } = router.query;
  const fetchData = async () => {
    setError(null);
    setSuccess(null);
    const { data, error } = await db
      .profile_page_view()
      .select()
      .eq("handle", handle as string)
      .limit(1)
      .single();
    if (error) {
      setError(error.message);
    }
    if (!error) {
      setSuccess("Success!!!");
      setProfileData(data);
    }
    const { data: organizationData, error: organizationError } = await db
      .organizations()
      .select("name, id");
    if (organizationError) {
      setError(organizationError.message);
    }
    if (!organizationError) {
      setOrganizations(organizationData);
      setSuccess("Success!!!");
      // setProfileData(data);
    }
  };

  useEffect(() => {
    if (!router.isReady) return;
    fetchData().finally(promiseLoadingHelper(userProfileLoadingItem));

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [router.isReady]);

  return (
    <>
      <div className="bg-gray-100 py-4 justify-center box-border w-full grid">
        {profileData && (
          <div className="grid px-8 gap-4 box-border grid-cols-1 max-w-7xl">
            <Modal open={open} setOpen={setOpen} title="Edit Profile">
              <EditProfileForm
                profile={profileData}
                setProfileData={setProfileData}
                setModal={setOpen}
                organizations={organizations ?? []}
              />
            </Modal>
            <Header profile={profileData} openEditModal={setOpen} />
            <About profile={profileData} />
            <Projects profile={profileData} />
            <Endorsements endorsements={profileData?.endorsements} />
          </div>
        )}
      </div>
    </>
  );
}
