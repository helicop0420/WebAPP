export { default } from "./UpdateDealModal";
