export interface StatusCircleProps {
  color: "text-green-600" | "text-yellow-300" | "text-red-600";
}
